package com.mobikode.statussaver.interfaces;

import java.io.File;

public interface FileListClickInterface {
    void getPosition(int position, File file);
}

package com.mobikode.statussaver.interfaces;


import com.mobikode.statussaver.model.story.TrayModel;

public interface UserListInterface {
    void userListClick(int position, TrayModel trayModel);
}
